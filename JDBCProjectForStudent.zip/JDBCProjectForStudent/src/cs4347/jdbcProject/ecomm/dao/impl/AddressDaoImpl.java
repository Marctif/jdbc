package cs4347.jdbcProject.ecomm.dao.impl;

import cs4347.jdbcProject.ecomm.dao.AddressDAO;

public class AddressDaoImpl implements AddressDAO
{

}
