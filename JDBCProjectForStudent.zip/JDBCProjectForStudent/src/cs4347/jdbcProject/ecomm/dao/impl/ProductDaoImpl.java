package cs4347.jdbcProject.ecomm.dao.impl;

import cs4347.jdbcProject.ecomm.dao.ProductDAO;

public class ProductDaoImpl implements ProductDAO
{

}
