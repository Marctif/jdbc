package cs4347.jdbcProject.ecomm.dao.impl;

import cs4347.jdbcProject.ecomm.dao.CustomerDAO;

public class CustomerDaoImpl implements CustomerDAO
{
	
}
